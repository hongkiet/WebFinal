<?php
    require_once('database.php');
    $error = '';
    if(isset($_POST['submit'])) {
        $song = $_POST['song'];
        $file = $_POST['file'];
        $singer = $_POST['singer'];
        $image = $_POST['image'];
        $album = $_POST['album'];
        $category = $_POST['category'];

        if($song == "") {
            $error = "LÀM ƠN ĐIỀN TÊN BÀI HÁT";
        } else if ($file == "./music/") {
            $error = "NHẬP FILE VÀO MỚI UPDATE LÊN DATABASE ĐƯỢC";
        } else if ($singer == "") {
            $error = "NHẬP TÊN CA SĨ CHỨ ĐỂ TRỐNG XẤU LẮM";
        } else if ($image == "./image/") {
            $error = "NHẬP ẢNH VÀO MỚI UPDATE LÊN DATABASE ĐƯỢC";
        } else if($album == '') {
            $error = "NHẬP TÊN ALBUM VÀO MỚI UPDATE LÊN DATABASE ĐƯỢC";
        } else if($category == '') {
            $error = "NHẬP TÊN THỂ LOẠI VÀO MỚI UPDATE LÊN DATABASE ĐƯỢC";
        } else {
            // Lưu thông tin vào cơ sở dữ liệu
            $result = add_music($song, $file, $singer, $image, $album, $category);
            if($result['code'] == 0) {
                $error = $result['success'];
                // Kiểm tra nếu tệp được tải lên thành công
                if(isset($_FILES['mp3File']) && $_FILES['mp3File']['error'] === UPLOAD_ERR_OK) {
                    $fileTmpPath = $_FILES['mp3File']['tmp_name'];
                    $fileName = $_FILES['mp3File']['name'];
                    $fileSize = $_FILES['mp3File']['size'];
                    $fileType = $_FILES['mp3File']['type'];
                    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
                    $supported_files = array('mp3', 'flac');
                    
                    if(in_array($ext, $supported_files)) {
                        $uploadPath = __DIR__ . '/music/' . $fileName;
                        if(move_uploaded_file($fileTmpPath, $uploadPath)) {
                            $error = "Tải tệp lên thành công.";
                        } else {
                            $error =  "Lỗi khi tải tệp lên.";
                        }
                    } else {
                        $error = "KHÔNG HỖ TRỢ ĐUÔI NHẠC NÀY ĐỂ TRÁNH BỊ LỖI";
                    }
                }
        
        // Kiểm tra nếu tệp được tải lên thành công
        
                if(isset($_FILES['imageFile']) && $_FILES['imageFile']['error'] === UPLOAD_ERR_OK) {
                    $fileTmpPath = $_FILES['imageFile']['tmp_name'];
                    $fileName = $_FILES['imageFile']['name'];
                    $fileSize = $_FILES['imageFile']['size'];
                    $fileType = $_FILES['imageFile']['type'];
                    $duoi = pathinfo($fileName, PATHINFO_EXTENSION);
                    $supported_image = array('png', 'jpg');
                    // Lưu tệp vào thư mục đã chỉ định
                    if(in_array($duoi, $supported_image)) {
                        $uploadPath = __DIR__ . '/image/' . $fileName;
                        if(move_uploaded_file($fileTmpPath, $uploadPath)) {
                            $error = "Tải tệp lên thành công.";
                        } else {
                            $error = "Lỗi khi tải tệp lên.";
                        }
                    } else {
                        $error = "KHÔNG HỖ TRỢ ĐUÔI ẢNH NÀY ĐỂ TRÁNH BỊ LỖI";
                    }
                }
            } else if($result['code'] == 1) {
                $error = $result['error'];
            }
        }
    }
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload Files and Update Database</title>
</head>
<style>
    .setting {
        /* padding: 5px 5px 5px; */
        padding-top: 50px;
        padding-left: 50px;
        padding-bottom: 50px;
        padding-right: 50px;
        margin-left: 30%;
        margin-top: 5%;
        border: 2px solid black;
        position: fixed;
        display: inline-block;
        /* justify-content: center; */
    }
</style>
<body>
	<form method="post" enctype="multipart/form-data">
        <div class="setting">
            <label for="mp3File">Upload MP3 File:</label>
            <input type="file" name="mp3File" id="mp3File"><br><br>
            <label for="imageFile">Upload Image File:</label>
            <input type="file" name="imageFile" id="imageFile"><br><br>

            <p style="color:red;"><strong>BẤM F5 ĐỂ REFRESH CHỨ ĐỪNG BẤM CTRL + F5</strong></p>
            <p style="color:red;"><strong>VÌ NHƯ THẾ FORM SẼ ĐƯỢC GỬI TRÙNG LẬP THÊM LẦN NỮA</strong></p>
            <p style="color:red;"><strong>ID BÀI HÁT SẼ ĐƯỢC TẠO TỰ ĐỘNG NÊN TRÁNH TRƯỜNG HỢP NÀY</strong></p>
            <p style="color:red;"><strong>NHẬP PHẦN NÀY ĐỂ THÊM DỮ LIỆU VÀO DATABASE</strong></p>
            <p style="color:red;"><strong>NHỚ NHẬP ĐÚNG THÔNG TIN CŨNG NHƯ CHỌN ĐÚNG LOẠI FILE ĐỂ ĐỠ PHẢI SỬA DATABASE</strong></p>
            <label for="name">Tên Bài Hát</label>
            <input name="song" type="text"><br><br>

            <label for="file">File (e.g: ./music/file.mp3 or ./music/file.wav)</label>
            <input name="file" value="./music/" type="text"><br><br>

            <label for="singer">Tên Ca Sĩ</label>
            <input name="singer" type="text"><br><br>

            <label for="image">Ảnh (e.g: ./image/file.jpg or ./image/file.png)</label>
            <input name="image" value="./image/" type="text"><br><br>

            <label for="album">Album</label>
            <input name="album" value="" type="text"><br><br>

            <label for="category">Thể Loại</label>
            <input name="category" value="" type="text"><br><br>

            <input type="submit" name="submit" value="Upload and Update">
            <?php
                if(!empty($error)) {
                    ?>
                        <div style="color: red;"><?=$error?></div>
                    <?php
                }
            ?>
        </div>
	</form>
</body>

</html>

