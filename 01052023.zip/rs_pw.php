<?php
    session_start();
    require_once('database_account.php');

    $error = '';

    $email = '';
    if (isset($_POST['email'])) {
        $email = $_POST['email'];

        if (empty($email)) {
            $error = 'Please enter your email';
        }
        else if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) {
            $error = 'This is not a valid email address';
        }
        else {
            $rs = ForgotPassword($email);
            print_r($rs);
            $error = 'If your email exists in the database, you will receive an email containing the reset password instructions!';
        }
    }
?>