<?php
    require_once('connection.php');
    function get_music() {
        $conn = connect_to_db();
        $m = $conn->query("SELECT * from displaymusic");

        $musics = [];
        for($i = 1; $i <= $m->num_rows; $i++) {
            $musics[] = $m->fetch_assoc();
        }
        return $musics;
    }
?>