/*
    Music:
        id
        title
        src
        img
*/
    const songs = document.querySelectorAll('.baihat');
    const player = document.getElementById('player');
    const playBtn = document.querySelector(".play-inner");
    const nextBtn = document.querySelector(".play-forward");
    const preBtn = document.querySelector(".play-back");
    const durationTime = document.querySelector(".duration");
    const remainingTime = document.querySelector(".remaining");
    const rangeBar = document.querySelector(".custom-progress-done");
    const range = document.querySelector(".progress-bar");
    const volumeBtn = document.querySelector(".volume-icon");
    const volrange = document.querySelector(".vol-bar-done");
    const vol = document.querySelector(".vol-bar");
    const num = document.querySelector(".num");
    player.volume = 1;
    var voltemp = 100 + "%";
    var check = 1;
    vol.addEventListener('click', function(e) {
        const progressWidth = vol.offsetWidth;
        const clickX = e.offsetX;
        const progressPercent = (clickX / progressWidth) * 100;
        volrange.style.width = progressPercent + "%";
        let isVolume;
        if(volrange.style.width <= 0 + "%") {
            player.volume = 0;
            voltemp = 0 + "%";
        } else {
            player.volume = (progressPercent / 100);
            voltemp = volrange.style.width;
        }
        if(player.volume == 0) {
            volumeBtn.innerHTML = '<i class="bi bi-volume-mute"></i>';
            isVolume = -1;
        } else if(player.volume <= 0.5) {
            isVolume = 0;
            volumeBtn.innerHTML = '<i class="bi bi-volume-down"></i>';
        } else if(player.volume <= 1) {
            isVolume = 1;
            volumeBtn.innerHTML = '<i class="bi bi-volume-up"></i>';
        }
        check = isVolume;
    });
    let preCheck;
        
    
    volumeBtn.addEventListener('click', function HandleVolume() {
        if(check == -1) {
            
            if(preCheck == 1) {
                check = 1;
                volumeBtn.innerHTML = '<i class="bi bi-volume-up"></i>';
            } else if(preCheck == 0) {
                check = 0;
                volumeBtn.innerHTML = '<i class="bi bi-volume-down"></i>';
            } else {
                volumeBtn.innerHTML = '<i class="bi bi-volume-mute"></i>';
            }
        } else if(check == 1) {
            preCheck = 1;
            check = -1;
            volumeBtn.innerHTML = '<i class="bi bi-volume-mute"></i>';
        } else if(check == 0) {
            preCheck = 0;
            check = -1;
            volumeBtn.innerHTML = '<i class="bi bi-volume-mute"></i>';
        } else {
            preCheck = -1;
        }
        
        if(check == -1) {
            volrange.style.width = 0 + "%";
        } else {
            volrange.style.width = voltemp;
        }
        player.volume = parseInt(volrange.style.width) / 100;

    });
    volrange.oninput = function() {
        if(voltemp == 0 + "%") {
            volumeBtn.innerHTML = '<i class="bi bi-volume-mute"></i>';
        }

    }
    let isShuffle = false;
    const playShuffle = document.querySelector(".play-shuffle");

    const playRepeat = document.querySelector(".repeat-icon");
    let isRepeat = -1;
    playRepeat.addEventListener("click", function() {
        if(isRepeat == 0) {
            isRepeat = 1;
            playRepeat.innerHTML = '<i class="bi bi-repeat-1"></i>';
            playRepeat.querySelector("i").setAttribute("style", "color: #ffb86c;");
        } 
        else if(isRepeat == -1){
            isRepeat = 0;
            playRepeat.querySelector("i").setAttribute("style", "color: #ffb86c;");
        } else if(isRepeat == 1){
            isRepeat = -1;
            playRepeat.innerHTML = '<i class="bi bi-repeat"></i>';
        }
    });

    function handleShuffle() {
        if(isShuffle == true) {
            isShuffle = false;
            playShuffle.removeAttribute("style");
        } else {
            isShuffle = true;
            playShuffle.style.color = "#ffb86c";
        }
    }
    playShuffle.addEventListener("click", handleShuffle);
    function removehandleShuffle() {
        playShuffle.removeEventListener("click", handleShuffle);
    }



    let currentSongIndex = 0;
    isPlaying = true;
    Timer();
    let timer;
    const anh = document.querySelector('.img');
    const ten = document.querySelector('.music-name');
    const casi = document.querySelector('.actor');
    songs.forEach(baihat => {
        baihat.addEventListener('click', () => {
            const id = baihat.dataset.id;
            const title = baihat.dataset.title;
            const file = baihat.dataset.file;
            const image = baihat.dataset.image;
            const actor = baihat.dataset.actor;
            
            anh.setAttribute("src", image);
            ten.innerHTML = title;
            casi.innerHTML = actor;
    
            player.setAttribute('src', file);
            isPlaying = true;
            playPause();
            currentSongIndex = parseInt(id) - 1;
      });
    });
    preBtn.addEventListener("click", function() {
        playPreSong();
    });
    nextBtn.addEventListener("click", function() {
        playNextSong();
    });
    function playNextSong() {
        if(isShuffle == true) {
                let random = Math.floor(Math.random() * songs.length + 1);
                random = Math.floor(Math.random() * songs.length + 1);
                if(random >= songs.length) {
                    random = Math.floor(Math.random() * songs.length);
                }
                currentSongIndex = random;
                const randomSong = songs[random];
                
                const file = randomSong.dataset.file;
                const title = randomSong.dataset.title;
                const image = randomSong.dataset.image;
                const actor = randomSong.dataset.actor;
                
                anh.setAttribute("src", image);
                ten.innerHTML = title;
                casi.innerHTML = actor;

                player.setAttribute('src', file);
                isPlaying = true;
                playPause();        
        } else {
            let nextIndex = (currentSongIndex + 1) % songs.length;
                if(nextIndex >= songs.length) {
                    nextIndex = 0;
                } else {
                    const nextSong = songs[nextIndex];
                    const file = nextSong.dataset.file;
                    const title = nextSong.dataset.title;
                    const image = nextSong.dataset.image;
                    const actor = nextSong.dataset.actor;
                    anh.setAttribute("src", image);
                    ten.innerHTML = title;
                    casi.innerHTML = actor;
                    player.setAttribute('src', file)
                    currentSongIndex = nextIndex;
                    isPlaying = true;
                    playPause();
                }
        }
    }
    function playPreSong() {
        if(isShuffle == true) {
            let random = Math.floor(Math.random() * songs.length + 1);
            random = Math.floor(Math.random() * songs.length + 1);
            if(random >= songs.length) {
                random = Math.floor(Math.random() * songs.length);
            }
            currentSongIndex = random;
            const randomSong = songs[random];
            const title = randomSong.dataset.title;
            const file = randomSong.dataset.file;
            const image = randomSong.dataset.image;
            const actor = randomSong.dataset.actor;
                
            anh.setAttribute("src", image);
            ten.innerHTML = title;
            casi.innerHTML = actor;
            player.setAttribute('src', file);
            isPlaying = true;
            playPause();
        } else {        
            let PreIndex = currentSongIndex - 1;
            if(PreIndex < 0) {
                PreIndex = songs.length - 1;
            }
            const PreSong = songs[PreIndex];
            const file = PreSong.dataset.file;
            const title = PreSong.dataset.title;
            const image = PreSong.dataset.image;
            const actor = PreSong.dataset.actor;
            anh.setAttribute("src", image);
            ten.innerHTML = title;
            casi.innerHTML = actor;
            player.setAttribute('src', file)
            currentSongIndex = PreIndex;
            isPlaying = true;
            playPause();
        }
    }

    playBtn.addEventListener("click", playPause);
        function playPause() {
            if(isPlaying) {
                playBtn.innerHTML = '<i class="bi bi-pause-circle"></i>';
                player.play();
                isPlaying = false;
                timer = setInterval(Timer, 500);
            } else {
                playBtn.innerHTML = '<i name="play" class="bi bi-play-circle"></i>';
                player.pause();
                isPlaying = true;
                clearInterval(timer);
        }
    }

    function Timer() {
        const {duration, currentTime} = player;
        const progressPercent = (currentTime / duration) * 100;
        // rangeBar.style.width = progressPercent + "%";
        remainingTime.textContent = formatTimer(currentTime);
        if(!duration) {
            durationTime.textContent = "00:00";
        } else {
            durationTime.textContent = formatTimer(duration);
        }
    }

    function formatTimer(time) {
        const minutes = Math.floor(time / 60);
        const seconds = Math.floor(time - minutes * 60);
        return `${minutes < 10 ? '0' + minutes: minutes}:${seconds < 10 ? '0' + seconds: seconds}`;
    }
    player.addEventListener('ended', () => {
        if(isShuffle == true) {
            let random = Math.floor(Math.random() * songs.length + 1);
            random = Math.floor(Math.random() * songs.length + 1);
            if(random >= songs.length) {
                random = Math.floor(Math.random() * songs.length);
            }
            currentSongIndex = random;
            const randomSong = songs[random];
            console.log(randomSong);
            const file = randomSong.dataset.file;
            player.setAttribute('src', file);
            isPlaying = true;
            playPause();
        } else {
            if(isRepeat == 1) {
                playRepeat.removeAttribute("style");
                isPlaying = true;
                playPause();
            } else if(isRepeat == -1) {
                playNextSong();
            } else if(isRepeat == 0) {
                playNextSong();
            }
        }
    });


    range.addEventListener('click', function(e) {
        
        const progressWidth = range.offsetWidth;
        const clickX = e.offsetX;
        const progressPercent = (clickX / progressWidth) * 100;
        rangeBar.style.width = progressPercent + "%";
        
        // if (progressPercent < 0) {
        //     progressPercent = 0;
        // } else if (progressPercent > 100) {
        //     progressPercent = 100;
        // }
        
        // rangeBar.style.width = progressPercent + "%";
        const currentTime = (progressPercent / 100) * player.duration;
        // if (!isNaN(currentTime)) {
            player.currentTime = currentTime;
        // }
        console.log(rangeBar.style.width);
    });
    

    