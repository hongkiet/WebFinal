-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th4 25, 2023 lúc 04:52 AM
-- Phiên bản máy phục vụ: 10.4.27-MariaDB
-- Phiên bản PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `music`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `displaymusic`
--

CREATE TABLE `displaymusic` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `file` text NOT NULL,
  `actor` varchar(255) DEFAULT NULL,
  `image` text DEFAULT NULL,
  `album` text DEFAULT NULL,
  `category` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `displaymusic`
--

INSERT INTO `displaymusic` (`id`, `name`, `file`, `actor`, `image`, `album`, `category`) VALUES
(1, 'Buông Đôi Tay Nhau Ra', './music/Buông Đôi Tay Nhau Ra.mp3', 'Sơn Tùng M-TP', './image/BuongDoiTayNhauRa.jpg', NULL, NULL),
(2, 'Chắc Ai Đó Sẽ Về', './music/Chắc Ai Đó Sẽ Về.mp3', 'Sơn Tùng M-TP', './image/ChacAiDoSeVe.jpg', NULL, NULL),
(3, 'Chạy Ngay Đi', './music/Chạy Ngay Đi.mp3', 'Sơn Tùng M-TP', './image/ChayNgayDi.jpg', NULL, NULL),
(4, 'Chúng Ta Không Thuộc Về Nhau', './music/Chúng Ta Không Thuộc Về Nhau.flac', 'Sơn Tùng M-TP', './image/ChungTaKhongThuocVeNhau.jpg', NULL, NULL),
(5, 'Chúng ta của hiện tại Beat', './musics/ChungTaCuaHienTaiBeat-SonTungMTP-6919087.mp3', 'Sơn Tùng M-TP', './image/ChungTaCuaHienTai.jpg', NULL, NULL),
(6, 'Đánh Mất Em', './music/Đánh Mất Em.mp3', 'Quang Đăng Trần', './image/DanhMatEm.jpg', NULL, NULL),
(7, 'Chúng ta của hiện tại', './music/Chúng Ta Của Hiện Tại.mp3', 'Sơn Tùng M-TP', './image/ChungTaCuaHienTai.jpg', NULL, NULL),
(8, 'Chuyện Rằng', './music/CHUYỆN RẰNG.mp3', 'Thịnh Suy', './image/ChuyenRang.jpg', NULL, NULL),
(9, 'Đã Lỡ Yêu Em Nhiều', './music/Đã Lỡ Yêu Em Nhiều.mp3', 'Justatee', './image/DaLoYeuEmNhieu.jpg', NULL, NULL),
(10, 'Đếm Ngày Xa Em', './music/Đếm Ngày Xa Em.mp3', 'Lou Hoàng ft Only C', './image/DemNgayXaEm.jpg', NULL, NULL),
(11, 'Muộn Rồi Mà Sao Còn', './music/MUỘN RỒI MÀ SAO CÒN.mp3', 'Sơn Tùng M-TP', './image/MuonRoiMaSaoCon.jpg', NULL, NULL),
(12, 'Nơi Này Có Anh', './music/NƠI NÀY CÓ ANH.mp3', 'Sơn Tùng M-TP', './image/NoiNayCoAnh.jpg', NULL, NULL),
(13, 'Thêm Bao Nhiêu Lâu', './music/Thêm Bao Nhiêu Lâu.mp3', 'Đạt G', './image/ThemBaoNhieuLau.jpg', NULL, NULL),
(14, 'Vì Anh Đâu Có Biết', './music/Vì Anh Đâu Có Biết.mp3', 'Vũ', './image/ViAnhDauCoBiet.jpg', NULL, NULL),
(15, 'Waiting For You', './music/Waiting For You.mp3', 'MONO', './image/WaitingForYou.jpg', NULL, NULL),
(16, 'Em Của Ngày Hôm Qua', './music/Em Của Ngày Hôm Qua.flac', 'Sơn Tùng M-TP', './image/EmCuaNgayHomQua.jpg', NULL, NULL),
(17, 'Hãy Trao Cho Anh', './music/Hãy Trao Cho Anh.flac', 'Sơn Tùng M-TP', './image/HayTraoChoAnh.jpg', NULL, NULL),
(18, 'Nắng Ấm Xa Dần', './music/Nắng Ấm Xa Dần .mp3', 'Sơn Tùng M-TP', './image/NangAmXaDan.jpg', NULL, NULL),
(19, 'Túy Âm', './music/Túy Âm.flac', 'Xesi', './image/TuyAm.jpg', NULL, NULL),
(20, 'There\'s No One At All', './music/ThereNoOneAtAll.mp3', 'Sơn Tùng M-TP', './image/There\'sNoOneAtAll.jpg', NULL, NULL),
(21, 'Gyutto', './music/Gyutto.mp3', 'Mosawo', './image/Gyutto.jpg', NULL, NULL),
(22, 'Mabataki  Back Number', './music/y2mate.com - 瞬きMabataki  Back Number Cover by Harutya  Osamu Lyrics Video.mp3', 'Harutya & Osamu', './image/BackNumber.jpg', NULL, NULL),
(23, 'Flower', './music/y2mate.com - JISOO  꽃FLOWER MV.mp3', 'JISOO', './image/Flower.jpg', NULL, NULL),
(24, 'Flower', './music/y2mate.com - Miley Cyrus  Flowers Official Video.mp3', 'Miley Cyrus', './image/MILEY_CYRUS_FLOWERS.jpg', NULL, NULL),
(25, 'All Falls Down', './music/All Falls Down.flac', 'Allan Walker', './image/All Falls Down.jpg', NULL, NULL),
(26, 'Alone', './music/Alone.flac', 'Allan Walker', './image/Alone.jpg', NULL, NULL),
(27, 'Here We Go', './music/Here We Go.mp3', 'Chris Classic', './image/Here We Go.jpg', NULL, NULL),
(28, 'Hero', './music/Hero.mp3', 'Cash Cash ft Christina Perri', './image/Hero Cash Cash.jpg', NULL, NULL),
(29, 'Heroes Tonight', './music/Heroes Tonight.mp3', 'Janji ft Johnning', './image/Heroes Tonight.jpg', NULL, NULL),
(30, 'Inside Out', './music/Inside Out.flac', 'Italobrothers', './image/Inside Out.jpg', NULL, NULL),
(31, 'Out Of Time', './music/Out Of Time (Feat. Eric Lumiere) [sagan Remix].mp3', 'Eric Lumiere', './image/Out Of Time.jpg', NULL, NULL),
(32, 'China O', './music/China O.mp3', '徐梦圆', './image/China O.jpg', NULL, NULL),
(33, 'Nỗi Nhớ Tựa Thiên Hà (所念皆星河)', './music/Nỗi Nhớ Tựa Thiên Hà (所念皆星河).mp3', 'No Lyrics Song', './image/Nỗi Nhớ Tựa Thiên Hà.jpg', NULL, NULL),
(34, 'Tiệc Trà Sao (星茶会)', './music/Tiệc Trà Sao (星茶会).mp3', 'Akjra', 'Tiệc Trà Sao.jpg', NULL, NULL),
(35, 'Windy Hill', './music/Windy Hill.mp3', '羽肿', './image/Windy Hill.jpg', NULL, NULL),
(36, 'Bất Vong  不忘', './music/Bất Vong  不忘 .mp3', 'Vương Nhất Bác', './image/Bất Vong  不忘.jpg', NULL, NULL),
(37, 'Mỹ Nhân Họa Quyển', './music/Mỹ Nhân Họa Quyển  美人畫卷.mp3', 'Văn Nhân Thính Thư', './image/Mỹ Nhân Họa Uyển.jpg', NULL, NULL),
(38, 'Ah, My Romantic Road', './music/Ah, My Romantic Road.flac', 'Pellek', './image/Ah, My Romantic Road.jpg', NULL, NULL),
(39, 'Akuma No Ko  悪魔の子', './music/Akuma No Ko  悪魔の子.mp3', 'Ai Higuchi', './image/Akuma No Ko  悪魔の.jpg', NULL, NULL),
(40, 'Clattanoia', './music/Clattanoia.mp3', 'OxT', './image/Clattanoia.jpg', NULL, NULL),
(41, 'Left And Right', './music/y2mate.com - Charlie Puth  Left And Right feat Jung Kook of BTS Official Video.mp3', 'Charlie Puth ', './image/Left And Right.jpg', NULL, NULL),
(42, 'Não Cá Vàng', './music/y2mate.com - NÃO CÁ VÀNG  ONLY C ft LOU HOÀNG  OFFICIAL MV 2017.mp3', 'ONLY C ft. LOU HOÀNG', './image/Não Cá Vàng.jpg', NULL, NULL),
(43, 'Yêu Em Dại Khờ', './music/y2mate.com - YÊU EM DẠI KHỜ  LOU HOÀNG  OFFICIAL MV.mp3', 'LOU HOÀNG', './image/Yêu Em Dại Khờ.jpg', NULL, NULL),
(44, 'Đau Để Trưởng Thành', './music/y2mate.com - ĐAU ĐỂ TRƯỞNG THÀNH  ONLYC  OFFICIAL MV.mp3', 'ONLY C', './image/Đau Để Trưởng Thành.jpg', NULL, NULL),
(45, 'Sweet But Psycho', './music/Sweet But Psycho.mp3', 'Ava Max', './image/Ava_Max_–_Sweet_but_Psycho.png', NULL, NULL),
(46, 'Requiem', './music/Requiem.mp3', 'Kanaria, Hoshimachi Suisei', './image/COVER.jpg', NULL, NULL),
(47, 'Idol', './music/Idol.mp3', 'YOASOBI', './image/Idol.png', NULL, NULL),
(48, 'Mephisto', './music/Mephisto.flac', 'Queen Bee', './image/Mephisto.jpg', NULL, NULL),
(49, 'Suzume', './music/Suzume.flac', 'RADWIMPS, Toaka', './image/Suzume.jpg', NULL, NULL),
(50, 'Kimi No Namae', './music/Kimi No Namae.mp3', 'Chiai Fujikawa', './image/KimiNoNamae.jpg', NULL, NULL),
(51, 'Akuma No Ko  / 悪魔の子', './music/Akuma No Ko  悪魔の子.mp3', 'Ai Higuchi', './image/AkumaNoKo.jpg', NULL, NULL),
(52, 'WILL', './music/WILL.mp3', 'TRUE', './image/Will.jpg', NULL, NULL),
(53, 'New Genesis', './music/New Genesis.mp3', 'Ado', './image/NewGenesis.png', NULL, NULL),
(54, 'Watashi Wa Saikyou', './music/Watashi Wa Saikyou.mp3', 'Ado', './image/WatashiWaSaikyou.png', NULL, NULL),
(55, 'Backlight', './music/Backlight.mp3', 'Ado', './image/Backlight.jpg', NULL, NULL),
(56, 'Fleeting Lullaby', './music/Fleeting Lullaby.mp3', 'Ado', './image/FleetingLullaby.jpg', NULL, NULL),
(57, 'Tot Musica', './music/Tot Musica.mp3', 'Ado', './image/TotMusica.png', NULL, NULL),
(58, 'Kaze No Yukue', './music/Kaze No Yukue.mp3', 'Ado', './image/KazeNoYukue.jpg', NULL, NULL),
(59, 'Sekai No Tsuzuki', './music/Sekai No Tsuzuki.mp3', 'Ado', './image/KazeNoYukue.jpg', NULL, NULL),
(60, 'Binks\' Sake', './music/Binks\' Sake.mp3', 'Ado', './image/Binks\'Sake.jpg', NULL, NULL),
(61, 'HOLLOW HUNGER', './music/HOLLOW HUNGER.flac', 'OxT', './image/HolowHunger.jpg', NULL, NULL),
(62, 'Unholy', './music/Unholy.mp3', 'Sam Smith, Kim Petras', './image/UnHoly.png', NULL, NULL),
(63, 'Phía Sau Em', './music/y2mate.com - PHÍA SAU EM  Kay Trần ft Binz Official Music Video.mp3', 'Kay Trần ft Binz', './image/Phía Sau Em.jpg', NULL, NULL),
(64, 'Rồi Ta Sẽ Ngắm Pháo Hoa Cùng Nhau', './music/y2mate.com - Rồi ta sẽ ngắm pháo hoa cùng nhau  Olew.mp3', 'O.lew', './image/Rồi Ta Sẽ Ngắm Pháo Hoa Cùng Nhau.jpg', NULL, NULL),
(65, 'Kẻ Theo Đuổi Ánh Sáng (Lofi)', './music/y2mate.com - Kẻ Theo Đuổi Ánh Sáng Lofi Ver  Huy Vạc x Tiến Nguyễn x Freak D.mp3', 'HUY VẠC', './image/Kẻ Theo Đuổi ánh sáng.jpg', NULL, NULL),
(66, 'Kẻ Theo Đuổi Ánh Sáng', './music/y2mate.com - Vietsub Người theo đuổi ánh sáng  Từ Vi.mp3', 'Từ Vi', './image/Kẻ Theo đuổi Ánh Sáng TV.jpg', NULL, NULL),
(67, 'Dynamite', './music/Dynamite-BTSBangtanBoys-6549057.mp3', 'BTS', './image/BTS.png', NULL, NULL),
(68, 'Eyes Nose Lips', './music/y2mate.com - TAEYANG 태양  Eyes Nose Lips 눈 코 입 Color Coded HanRomEng Lyrics.mp3', 'TAEYANG (태양)', './image/EyesNoseLips.jpg', NULL, NULL),
(69, 'Star Walkin\'', './music/Star Walkin\'.flac', 'Lil Nas X', './image/StartWalkin.jpg', NULL, NULL),
(70, 'Anh Chưa Thương Em Đến Vậy Đâu', './music/y2mate.com - Anh Chưa Thương Em Đến Vậy Đâu  Lady Mây LyricsEngsub.mp3', 'Lady Mây', './image/AnhChuaThuongEmDenVayDau.jpg', NULL, NULL),
(71, 'Shinda!', './music/Shinda.flac', 'Masayoshi Oishi', './image/Shinda.jpg', NULL, NULL),
(72, 'Kick Back', './music/Kick Back.mp3', 'Kenshi Yonezu', './image/KickBack.jpg', NULL, NULL),
(73, 'Chainsaw Blood', './music/Chainsaw Blood.mp3', 'Vaundy', './image/ChainsawBlood.jpg', NULL, NULL),
(74, 'Time Left', './music/Time Left.mp3', 'ZUTOMAYO', './image/TimeLeft.jpg', NULL, NULL),
(75, 'Hawatari Nioku Centi', './music/Hawatari Nioku Centi.mp3', 'MAXIMUM THE HORMONE', './image/HawatariNiokuCenti.jpg', NULL, NULL),
(76, 'Tablet.', './music/Tablet.mp3', 'TOOBOE', './image/Tablet.jpg', NULL, NULL),
(77, 'In The Back Room', './music/In The Back Room.mp3', 'Syudou', './image/InTheBackRoom.jpg', NULL, NULL),
(78, 'Rendezvous', './music/Rendezvous.mp3', 'Kanaria', './image/Rendezvous.jpg', NULL, NULL),
(79, 'Chu, Tayousei.', './music/Chu, Tayousei..mp3', 'Ano', './image/ChuTayousei.jpg', NULL, NULL),
(80, 'Deep Down', './music/Deep Down.mp3', 'Aimer', './image/FirstDeath.jpg', NULL, NULL),
(81, 'First Death', './music/First Death.mp3', 'TK (Ling Tosite Sigure)', './image/FirstDeath.jpg', NULL, NULL),
(82, 'DOGLAND', './music/Dogland.mp3', 'People 1', './image/DogLand.jpg', NULL, NULL),
(83, 'Violence', './music/Violence.mp3', 'Queen Bee', './image/Violence.jpg', NULL, NULL),
(84, 'Fight Song', './music/Fight Song.mp3', 'Eve', './image/FightSong.jpg', NULL, NULL);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `displaymusic`
--
ALTER TABLE `displaymusic`
  ADD UNIQUE KEY `id` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
